
/**
 * Player.java  
 *
 * @author:
 * Assignment #:
 * 
 * Brief Program Description:
 * 
 *
 */
public class Player
{
    private Hand hand;
    private boolean hasInsurance;
    private int chips;
    public Player(int numChips)
    {
        hand = new Hand();
        hasInsurance = false;
        chips = numChips;
    }
    
    public void hit()
    {
        hand.add(Dealer.dealCard());
    }
    
    public void doubleDown()
    {
        int a = chips - getChipsPlayedPlayer();
        chips -= getChipsPlayedPlayer();
        Dealer.addChipsPlayedPlayer(a);
        hand.add(Dealer.dealCard());
    }
    
    public void buyInsurance()
    {
        
    }
    
}
