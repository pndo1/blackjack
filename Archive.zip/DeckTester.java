
/**
 * Write a description of class DeckTester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DeckTester
{
    public static void main (String[] args)
    {
        Deck d = new Deck();
        d.printDeck();
        d.shuffleDeck();
        d.printDeck();
    }
}
